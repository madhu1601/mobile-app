import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'api_service.dart';

// ── Background message handler (top-level, outside any class) ─
@pragma('vm:entry-point')
Future<void> firebaseBackgroundHandler(RemoteMessage message) async {
  // Firebase must be initialized before using it in background
  await Firebase.initializeApp();
  // The system tray notification is shown automatically by FCM
  // when the app is in background/killed for data+notification messages.
  // Nothing extra needed here unless you want custom handling.
}

// ── Notification channel IDs ──────────────────────────────────
const String _channelId   = 'mdtelecom_orders';
const String _channelName = 'MD Telecom Orders';
const String _channelDesc = 'Order and workflow notifications';

class NotificationService {
  static final NotificationService _instance = NotificationService._();
  factory NotificationService() => _instance;
  NotificationService._();

  final FirebaseMessaging          _fcm   = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();

  // Callback when user taps a notification (to navigate)
  Function(Map<String, dynamic>)? onNotificationTap;

  // ── Initialize everything ─────────────────────────────────
  Future<void> init() async {
    // 1. Request permission (iOS + Android 13+)
    final settings = await _fcm.requestPermission(
      alert:       true,
      badge:       true,
      sound:       true,
      provisional: false,
    );

    debugPrint('[FCM] Permission: ${settings.authorizationStatus}');

    // 2. Set up local notifications (for foreground display)
    await _initLocalNotifications();

    // 3. Register background handler
    FirebaseMessaging.onBackgroundMessage(firebaseBackgroundHandler);

    // 4. Foreground message handler
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

    // 5. App opened from notification (background → foreground)
    FirebaseMessaging.onMessageOpenedApp.listen(_handleNotificationTap);

    // 6. App launched from terminated state via notification
    final initialMessage = await _fcm.getInitialMessage();
    if (initialMessage != null) {
      _handleNotificationTap(initialMessage);
    }

    // 7. Android: show foreground notifications
    await _fcm.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }

  // ── Get FCM token and save to backend ─────────────────────
  Future<String?> getAndSaveToken(ApiService api) async {
    try {
      final token = await _fcm.getToken();
      debugPrint('[FCM] Device token: $token');

      if (token != null) {
        await api.saveFcmToken(token);
        debugPrint('[FCM] Token saved to backend');
      }

      // Listen for token refresh
      _fcm.onTokenRefresh.listen((newToken) async {
        debugPrint('[FCM] Token refreshed: $newToken');
        await api.saveFcmToken(newToken);
      });

      return token;
    } catch (e) {
      debugPrint('[FCM] Error getting token: $e');
      return null;
    }
  }

  // ── Local notifications setup ─────────────────────────────
  Future<void> _initLocalNotifications() async {
    // Android channel
    const androidChannel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: _channelDesc,
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
    );

    final androidPlugin = _local.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(androidChannel);

    // Init settings
    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      ),
    );

    await _local.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (details) {
        // User tapped local notification
        if (details.payload != null) {
          _handlePayload(details.payload!);
        }
      },
    );
  }

  // ── Show local notification (foreground) ──────────────────
  Future<void> _showLocalNotification(RemoteMessage message) async {
    final notification = message.notification;
    if (notification == null) return;

    final androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDesc,
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      icon: '@mipmap/ic_launcher',
      styleInformation: BigTextStyleInformation(
        notification.body ?? '',
        contentTitle: notification.title,
      ),
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final details = NotificationDetails(
        android: androidDetails, iOS: iosDetails);

    await _local.show(
      message.hashCode,
      notification.title,
      notification.body,
      details,
      payload: _encodePayload(message.data),
    );
  }

  // ── Handlers ──────────────────────────────────────────────
  void _handleForegroundMessage(RemoteMessage message) {
    debugPrint('[FCM] Foreground message: ${message.notification?.title}');
    _showLocalNotification(message);
  }

  void _handleNotificationTap(RemoteMessage message) {
    debugPrint('[FCM] Notification tapped: ${message.data}');
    if (onNotificationTap != null) {
      onNotificationTap!(message.data);
    }
  }

  void _handlePayload(String payload) {
    // payload is "key=value&key=value" encoded
    final data = Uri.splitQueryString(payload);
    if (onNotificationTap != null) {
      onNotificationTap!(data);
    }
  }

  String _encodePayload(Map<String, dynamic> data) {
    return data.entries.map((e) => '${e.key}=${e.value}').join('&');
  }
}

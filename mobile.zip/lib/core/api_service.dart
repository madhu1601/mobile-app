import 'dart:convert';
import 'package:http/http.dart' as http;
import 'constants.dart';

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  String? _token;
  void setToken(String? t) => _token = t;
  String? get token => _token;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  // ── Auth ─────────────────────────────────────────────────────
  Future<Map<String, dynamic>> login(String identifier, String password) =>
      _post('/auth/login', {'identifier': identifier, 'password': password});

  Future<Map<String, dynamic>> register(Map<String, dynamic> data) =>
      _post('/auth/register', data);

  Future<Map<String, dynamic>> logout() => _post('/auth/logout', {});

  Future<Map<String, dynamic>> saveFcmToken(String fcmToken) =>
      _post('/auth/fcm-token', {'fcm_token': fcmToken});

  // ── Dashboard ─────────────────────────────────────────────────
  Future<Map<String, dynamic>> getDashboard() => _get('/dashboard');

  // ── Products ──────────────────────────────────────────────────
  Future<Map<String, dynamic>> getProducts({int? categoryId, String? search}) {
    final params = <String, String>{};
    if (categoryId != null) params['category_id'] = '$categoryId';
    if (search != null && search.isNotEmpty) params['search'] = search;
    return _get('/products', params: params);
  }

  Future<Map<String, dynamic>> getProduct(int id) => _get('/products/$id');

  Future<Map<String, dynamic>> createProduct(Map<String, dynamic> data) =>
      _post('/products', data);

  Future<Map<String, dynamic>> updateProduct(int id, Map<String, dynamic> data) =>
      _put('/products/$id', data);

  Future<Map<String, dynamic>> deleteProduct(int id) =>
      _delete('/products/$id');

  // ── Categories ────────────────────────────────────────────────
  Future<Map<String, dynamic>> getCategories() => _get('/categories');

  Future<Map<String, dynamic>> createCategory(String name) =>
      _post('/categories', {'name': name});

  Future<Map<String, dynamic>> updateCategory(int id, Map<String, dynamic> data) =>
      _put('/categories/$id', data);

  Future<Map<String, dynamic>> deleteCategory(int id) =>
      _delete('/categories/$id');

  // ── Models ────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getModels({int? categoryId}) {
    final params = <String, String>{};
    if (categoryId != null) params['category_id'] = '$categoryId';
    return _get('/models', params: params);
  }

  Future<Map<String, dynamic>> createModel(Map<String, dynamic> data) =>
      _post('/models', data);

  Future<Map<String, dynamic>> updateModel(int id, Map<String, dynamic> data) =>
      _put('/models/$id', data);

  // ── Users ─────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getUsers({String? role}) {
    final params = <String, String>{};
    if (role != null) params['role'] = role;
    return _get('/users', params: params);
  }

  Future<Map<String, dynamic>> getMakers()   => _get('/users/makers');
  Future<Map<String, dynamic>> getCheckers() => _get('/users/checkers');

  Future<Map<String, dynamic>> createUser(Map<String, dynamic> data) =>
      _post('/users', data);

  Future<Map<String, dynamic>> updateUser(int id, Map<String, dynamic> data) =>
      _put('/users/$id', data);

  Future<Map<String, dynamic>> toggleUser(int id) =>
      _post('/users/$id/toggle', {});

  // ── Customers ─────────────────────────────────────────────────
  Future<Map<String, dynamic>> getCustomers() => _get('/customers');
  Future<Map<String, dynamic>> getCustomer(int id) => _get('/customers/$id');

  // ── Orders ────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getOrders({String? status}) {
    final params = <String, String>{};
    if (status != null) params['status'] = status;
    return _get('/orders', params: params);
  }

  Future<Map<String, dynamic>> getOrder(int id) => _get('/orders/$id');

  Future<Map<String, dynamic>> placeOrder(List<Map<String, dynamic>> items, {String? notes}) =>
      _post('/orders', {'items': items, if (notes != null) 'notes': notes});

  Future<Map<String, dynamic>> assignOrder(int id, int makerId, int checkerId) =>
      _post('/orders/$id/assign', {'maker_id': makerId, 'checker_id': checkerId});

  Future<Map<String, dynamic>> updateOrderStatus(int id, String status, {String? remarks}) =>
      _post('/orders/$id/status', {'status': status, if (remarks != null) 'remarks': remarks});

  Future<Map<String, dynamic>> editOrderItem(int itemId, int qty) =>
      _post('/orders/item/edit', {'item_id': itemId, 'quantity': qty});

  Future<Map<String, dynamic>> deleteOrderItem(int itemId) =>
      _post('/orders/item/delete', {'item_id': itemId});

  // ── Payments ──────────────────────────────────────────────────
  Future<Map<String, dynamic>> addPayment(Map<String, dynamic> data) =>
      _post('/payments', data);

  Future<Map<String, dynamic>> getPayments(int orderId) =>
      _get('/payments/$orderId');

  // ── Notifications ─────────────────────────────────────────────
  Future<Map<String, dynamic>> getNotifications() => _get('/notifications');
  Future<Map<String, dynamic>> markAllRead() => _post('/notifications/read-all', {});

  // ── HTTP Helpers ──────────────────────────────────────────────
  Future<Map<String, dynamic>> _get(String path, {Map<String, String>? params}) async {
    var uri = Uri.parse('${AppConstants.baseUrl}$path');
    if (params != null && params.isNotEmpty) {
      uri = uri.replace(queryParameters: params);
    }
    final res = await http.get(uri, headers: _headers);
    return _handle(res);
  }

  Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> body) async {
    final uri = Uri.parse('${AppConstants.baseUrl}$path');
    final res = await http.post(uri, headers: _headers, body: jsonEncode(body));
    return _handle(res);
  }

  Future<Map<String, dynamic>> _put(String path, Map<String, dynamic> body) async {
    final uri = Uri.parse('${AppConstants.baseUrl}$path');
    final res = await http.put(uri, headers: _headers, body: jsonEncode(body));
    return _handle(res);
  }

  Future<Map<String, dynamic>> _delete(String path) async {
    final uri = Uri.parse('${AppConstants.baseUrl}$path');
    final res = await http.delete(uri, headers: _headers);
    return _handle(res);
  }

  Map<String, dynamic> _handle(http.Response res) {
    final decoded = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode >= 200 && res.statusCode < 300) return decoded;
    throw ApiException(decoded['message'] as String? ?? 'Error', res.statusCode);
  }
}

class ApiException implements Exception {
  final String message;
  final int statusCode;
  const ApiException(this.message, this.statusCode);
  @override
  String toString() => message;
}

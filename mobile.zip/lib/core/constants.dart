class AppConstants {
  // ── API Base URL ─────────────────────────────────────────────
  // Live:  https://101connect.in/mobile_app/api
  // Local: http://10.0.2.2/mdtelecomMobile/backend/public/api
  static const String baseUrl = 'https://101connect.in/mobile_app/api';

  // ── Colors ───────────────────────────────────────────────────
  static const int primaryInt    = 0xFF5C6BC0; // indigo/purple
  static const int navyInt       = 0xFF1E2A3A;
  static const int orangeInt     = 0xFFF57C00;
  static const int tealInt       = 0xFF00897B;
  static const int greenInt      = 0xFF43A047;
  static const int redInt        = 0xFFE53935;
  static const int bgInt         = 0xFFF5F6FA;
}

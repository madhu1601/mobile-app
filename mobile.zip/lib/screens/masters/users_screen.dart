import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});
  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final res = await context.read<AuthProvider>().api.getUsers();
      setState(() { _users = (res['data'] as List).cast<Map<String, dynamic>>(); _loading = false; });
    } catch (_) { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('User Master'),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: () => _showForm(context)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _users.length,
                itemBuilder: (ctx, i) {
                  final u = _users[i];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: AppTheme.primary.withOpacity(0.1),
                          child: Text((u['name'] as String).substring(0, 1).toUpperCase(),
                              style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(u['name'] as String,
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                              Text(u['email'] ?? u['mobile'] ?? '',
                                  style: const TextStyle(color: Colors.grey, fontSize: 11)),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppTheme.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(u['role_label'] as String? ?? '',
                              style: const TextStyle(color: AppTheme.primary, fontSize: 10)),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 8, height: 8,
                          decoration: BoxDecoration(
                            color: (u['is_active'] as int? ?? 1) == 1 ? AppTheme.green : AppTheme.red,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
    );
  }

  void _showForm(BuildContext context) {
    final nameCtrl     = TextEditingController();
    final emailCtrl    = TextEditingController();
    final mobileCtrl   = TextEditingController();
    final passwordCtrl = TextEditingController();
    int roleId = 2;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          left: 20, right: 20, top: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: StatefulBuilder(builder: (ctx, setS) => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Add User', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Full Name *', isDense: true)),
            const SizedBox(height: 10),
            TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'Email', isDense: true)),
            const SizedBox(height: 10),
            TextField(controller: mobileCtrl, decoration: const InputDecoration(labelText: 'Mobile', isDense: true), keyboardType: TextInputType.phone),
            const SizedBox(height: 10),
            TextField(controller: passwordCtrl, decoration: const InputDecoration(labelText: 'Password *', isDense: true), obscureText: true),
            const SizedBox(height: 10),
            DropdownButtonFormField<int>(
              value: roleId,
              decoration: const InputDecoration(labelText: 'Role', isDense: true),
              items: const [
                DropdownMenuItem(value: 1, child: Text('Admin')),
                DropdownMenuItem(value: 2, child: Text('Customer')),
                DropdownMenuItem(value: 3, child: Text('Maker')),
                DropdownMenuItem(value: 4, child: Text('Checker')),
                DropdownMenuItem(value: 5, child: Text('Accountant')),
              ],
              onChanged: (v) => setS(() => roleId = v!),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  if (nameCtrl.text.isEmpty || passwordCtrl.text.isEmpty) return;
                  await context.read<AuthProvider>().api.createUser({
                    'name': nameCtrl.text, 'email': emailCtrl.text,
                    'mobile': mobileCtrl.text, 'password': passwordCtrl.text,
                    'role_id': roleId,
                  });
                  if (context.mounted) { Navigator.pop(context); _load(); }
                },
                child: const Text('Create User'),
              ),
            ),
          ],
        )),
      ),
    );
  }
}

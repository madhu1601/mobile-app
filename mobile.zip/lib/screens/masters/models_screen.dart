import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';

class ModelsScreen extends StatefulWidget {
  const ModelsScreen({super.key});
  @override
  State<ModelsScreen> createState() => _ModelsScreenState();
}

class _ModelsScreenState extends State<ModelsScreen> {
  List<Map<String, dynamic>> _models = [];
  List<Map<String, dynamic>> _cats   = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final api = context.read<AuthProvider>().api;
      final results = await Future.wait([api.getModels(), api.getCategories()]);
      setState(() {
        _models  = (results[0]['data'] as List).cast<Map<String, dynamic>>();
        _cats    = (results[1]['data'] as List).cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (_) { setState(() => _loading = false); }
  }

  void _showForm({Map<String, dynamic>? model}) {
    final nameCtrl = TextEditingController(text: model?['name'] as String? ?? '');
    int? catId = model?['category_id'] as int?;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(context).viewInsets.bottom + 20),
        child: StatefulBuilder(builder: (ctx, setS) => Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(model == null ? 'Add Model' : 'Edit Model',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              value: catId,
              decoration: const InputDecoration(labelText: 'Category *', isDense: true),
              items: _cats.map((c) =>
                  DropdownMenuItem(value: c['id'] as int, child: Text(c['name'] as String))).toList(),
              onChanged: (v) => setS(() => catId = v),
            ),
            const SizedBox(height: 10),
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Model Name *', isDense: true)),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  if (nameCtrl.text.isEmpty || catId == null) return;
                  final api = context.read<AuthProvider>().api;
                  if (model == null) {
                    await api.createModel({'name': nameCtrl.text, 'category_id': catId});
                  } else {
                    await api.updateModel(model['id'] as int, {'name': nameCtrl.text, 'category_id': catId, 'is_active': 1});
                  }
                  if (context.mounted) { Navigator.pop(context); _load(); }
                },
                child: Text(model == null ? 'Create' : 'Update'),
              ),
            ),
          ],
        )),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('Model Master'),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
        actions: [IconButton(icon: const Icon(Icons.add), onPressed: () => _showForm())],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _models.length,
                itemBuilder: (ctx, i) {
                  final m = _models[i];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
                    ),
                    child: ListTile(
                      leading: Container(
                        width: 36, height: 36,
                        decoration: BoxDecoration(
                          color: AppTheme.orange.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.phone_android_outlined, color: AppTheme.orange, size: 18),
                      ),
                      title: Text(m['name'] as String,
                          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                      subtitle: Text(m['category_name'] as String? ?? '',
                          style: const TextStyle(fontSize: 11)),
                      trailing: IconButton(
                        icon: const Icon(Icons.edit_outlined, size: 18, color: AppTheme.primary),
                        onPressed: () => _showForm(model: m),
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }
}

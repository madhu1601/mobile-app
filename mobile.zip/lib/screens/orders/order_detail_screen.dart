import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/order_model.dart';

class OrderDetailScreen extends StatefulWidget {
  final int orderId;
  const OrderDetailScreen({super.key, required this.orderId});
  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final api = context.read<AuthProvider>().api;
    await context.read<OrderProvider>().fetchOrder(api, widget.orderId);
  }

  @override
  Widget build(BuildContext context) {
    final orderProv = context.watch<OrderProvider>();
    final auth      = context.watch<AuthProvider>();
    final role      = auth.user?.role ?? '';
    final order     = orderProv.current;

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: Text(order != null ? 'Order #${order.orderNumber}' : 'Order Detail'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
        ],
      ),
      body: orderProv.loading
          ? const Center(child: CircularProgressIndicator())
          : order == null
              ? const Center(child: Text('Order not found'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _InfoCard(order: order),
                        const SizedBox(height: 12),
                        _ItemsCard(order: order, role: role, orderProv: orderProv, api: auth.api),
                        const SizedBox(height: 12),
                        if (role == 'admin') ...[
                          _AssignCard(order: order, orderProv: orderProv, api: auth.api),
                          const SizedBox(height: 12),
                        ],
                        _StatusCard(order: order, role: role, orderProv: orderProv, api: auth.api),
                        const SizedBox(height: 12),
                        _HistoryCard(history: order.history),
                        const SizedBox(height: 80),
                      ],
                    ),
                  ),
                ),
    );
  }
}

// ── Info card ─────────────────────────────────────────────────
class _InfoCard extends StatelessWidget {
  final OrderModel order;
  const _InfoCard({required this.order});

  @override
  Widget build(BuildContext context) {
    final statusColors = {
      'pending': AppTheme.orange, 'completed': AppTheme.green,
      'rejected': AppTheme.red, 'assigned': AppTheme.primary,
      'maker_review': Colors.purple, 'checker_review': Colors.indigo,
      'confirmed': AppTheme.teal,
    };
    final color = statusColors[order.status] ?? Colors.grey;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: Text(order.orderNumber,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(order.statusLabel,
                    style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const Divider(height: 20),
          _DetailRow('Customer', order.customerName),
          _DetailRow('Mobile', order.customerMobile ?? '—'),
          _DetailRow('Maker', order.makerName ?? 'Not assigned'),
          _DetailRow('Checker', order.checkerName ?? 'Not assigned'),
          _DetailRow('Total', '₹${order.totalAmount.toStringAsFixed(2)}'),
          _DetailRow('Paid', '₹${order.paidAmount.toStringAsFixed(2)}'),
          _DetailRow('Balance', '₹${order.balance.toStringAsFixed(2)}',
              valueColor: order.balance > 0 ? AppTheme.red : AppTheme.green),
          _DetailRow('Date', order.createdAt.substring(0, 10)),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  const _DetailRow(this.label, this.value, {this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          SizedBox(width: 90, child: Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12))),
          Expanded(child: Text(value,
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: valueColor ?? Colors.black87))),
        ],
      ),
    );
  }
}

// ── Items card ────────────────────────────────────────────────
class _ItemsCard extends StatelessWidget {
  final OrderModel order;
  final String role;
  final OrderProvider orderProv;
  final dynamic api;
  const _ItemsCard({required this.order, required this.role, required this.orderProv, required this.api});

  bool get canEdit => ['admin', 'maker', 'checker'].contains(role);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Order Items', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 12),
          ...order.items.map((item) => _ItemRow(
                item: item, canEdit: canEdit,
                onQtyChange: (qty) async {
                  await orderProv.editItem(api, item.id, qty);
                },
                onDelete: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('Remove Item'),
                      content: Text('Remove ${item.productName}?'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                        TextButton(onPressed: () => Navigator.pop(context, true),
                            child: const Text('Remove', style: TextStyle(color: AppTheme.red))),
                      ],
                    ),
                  );
                  if (confirm == true) await orderProv.deleteItem(api, item.id);
                },
              )),
          const Divider(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Total', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('₹${order.totalAmount.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppTheme.primary)),
            ],
          ),
        ],
      ),
    );
  }
}

class _ItemRow extends StatefulWidget {
  final OrderItemModel item;
  final bool canEdit;
  final Function(int) onQtyChange;
  final VoidCallback onDelete;
  const _ItemRow({required this.item, required this.canEdit, required this.onQtyChange, required this.onDelete});
  @override
  State<_ItemRow> createState() => _ItemRowState();
}

class _ItemRowState extends State<_ItemRow> {
  late int _qty;
  @override
  void initState() { super.initState(); _qty = widget.item.quantity; }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.item.productName,
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                Text('₹${widget.item.unitPrice.toStringAsFixed(2)} each',
                    style: const TextStyle(color: Colors.grey, fontSize: 11)),
              ],
            ),
          ),
          if (widget.canEdit) ...[
            Row(children: [
              _QtyBtn(Icons.remove, () {
                if (_qty > 1) { setState(() => _qty--); widget.onQtyChange(_qty); }
              }),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text('$_qty', style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
              _QtyBtn(Icons.add, () { setState(() => _qty++); widget.onQtyChange(_qty); }),
            ]),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: widget.onDelete,
              child: const Icon(Icons.delete_outline, color: AppTheme.red, size: 20),
            ),
          ] else
            Text('×$_qty', style: const TextStyle(color: Colors.grey)),
          const SizedBox(width: 8),
          Text('₹${widget.item.subtotal.toStringAsFixed(2)}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        ],
      ),
    );
  }
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyBtn(this.icon, this.onTap);
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 26, height: 26,
        decoration: BoxDecoration(
          color: AppTheme.primary.withOpacity(0.1),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Icon(icon, size: 14, color: AppTheme.primary),
      ),
    );
  }
}

// ── Assign card (admin) ───────────────────────────────────────
class _AssignCard extends StatefulWidget {
  final OrderModel order;
  final OrderProvider orderProv;
  final dynamic api;
  const _AssignCard({required this.order, required this.orderProv, required this.api});
  @override
  State<_AssignCard> createState() => _AssignCardState();
}

class _AssignCardState extends State<_AssignCard> {
  int? _makerId;
  int? _checkerId;
  List<Map<String, dynamic>> _makers   = [];
  List<Map<String, dynamic>> _checkers = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    try {
      final results = await Future.wait([widget.api.getMakers(), widget.api.getCheckers()]);
      setState(() {
        _makers   = (results[0]['data'] as List<dynamic>).cast<Map<String, dynamic>>();
        _checkers = (results[1]['data'] as List<dynamic>).cast<Map<String, dynamic>>();
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (!['pending', 'assigned'].contains(widget.order.status)) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Assign Order', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            value: _makerId,
            decoration: const InputDecoration(labelText: 'Assign to Maker', isDense: true),
            items: _makers.map((m) =>
                DropdownMenuItem(value: m['id'] as int, child: Text(m['name'] as String))).toList(),
            onChanged: (v) => setState(() => _makerId = v),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<int>(
            value: _checkerId,
            decoration: const InputDecoration(labelText: 'Assign to Checker', isDense: true),
            items: _checkers.map((c) =>
                DropdownMenuItem(value: c['id'] as int, child: Text(c['name'] as String))).toList(),
            onChanged: (v) => setState(() => _checkerId = v),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _loading || _makerId == null || _checkerId == null ? null : () async {
                setState(() => _loading = true);
                await widget.orderProv.assignOrder(widget.api, widget.order.id, _makerId!, _checkerId!);
                setState(() => _loading = false);
              },
              child: _loading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('Assign'),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Status update card ────────────────────────────────────────
class _StatusCard extends StatefulWidget {
  final OrderModel order;
  final String role;
  final OrderProvider orderProv;
  final dynamic api;
  const _StatusCard({required this.order, required this.role, required this.orderProv, required this.api});
  @override
  State<_StatusCard> createState() => _StatusCardState();
}

class _StatusCardState extends State<_StatusCard> {
  String? _newStatus;
  final _remarksCtrl = TextEditingController();
  bool _loading = false;

  List<String> get _allowed {
    switch (widget.role) {
      case 'admin':   return ['assigned','maker_review','checker_review','confirmed','completed','rejected'];
      case 'maker':   return ['maker_review'];
      case 'checker': return ['checker_review'];
      default:        return [];
    }
  }

  @override
  void dispose() { _remarksCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_allowed.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Update Status', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _newStatus,
            decoration: const InputDecoration(labelText: 'New Status', isDense: true),
            items: _allowed.map((s) => DropdownMenuItem(
                value: s,
                child: Text(s.replaceAll('_', ' ').toUpperCase(),
                    style: const TextStyle(fontSize: 13)))).toList(),
            onChanged: (v) => setState(() => _newStatus = v),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _remarksCtrl,
            decoration: const InputDecoration(
                labelText: 'Remarks (optional)', isDense: true),
            maxLines: 2,
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _loading || _newStatus == null ? null : () async {
                setState(() => _loading = true);
                await widget.orderProv.updateStatus(
                    widget.api, widget.order.id, _newStatus!,
                    remarks: _remarksCtrl.text.trim());
                setState(() => _loading = false);
              },
              child: _loading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('Update Status'),
            ),
          ),
        ],
      ),
    );
  }
}

// ── History card ──────────────────────────────────────────────
class _HistoryCard extends StatelessWidget {
  final List<OrderHistoryModel> history;
  const _HistoryCard({required this.history});

  @override
  Widget build(BuildContext context) {
    if (history.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Order History', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 12),
          ...history.map((h) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(children: [
                      Container(
                        width: 10, height: 10,
                        decoration: const BoxDecoration(color: AppTheme.primary, shape: BoxShape.circle),
                      ),
                      Container(width: 1, height: 30, color: const Color(0xFFE0E0E0)),
                    ]),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Text(h.userName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.grey[100],
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(h.roleLabel, style: const TextStyle(fontSize: 9, color: Colors.grey)),
                            ),
                          ]),
                          if (h.toStatus != null) ...[
                            const SizedBox(height: 3),
                            Row(children: [
                              if (h.fromStatus != null) ...[
                                _StatusPill(h.fromStatus!),
                                const Icon(Icons.arrow_forward, size: 10, color: Colors.grey),
                              ],
                              _StatusPill(h.toStatus!),
                            ]),
                          ],
                          if (h.remarks != null && h.remarks!.isNotEmpty) ...[
                            const SizedBox(height: 2),
                            Text(h.remarks!, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                          ],
                          const SizedBox(height: 2),
                          Text(h.createdAt.substring(0, 16),
                              style: const TextStyle(fontSize: 10, color: Colors.grey)),
                        ],
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  final String status;
  const _StatusPill(this.status);
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 4),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(status.replaceAll('_', ' ').toUpperCase(),
          style: const TextStyle(fontSize: 9, color: AppTheme.primary, fontWeight: FontWeight.bold)),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../models/product_model.dart';
import '../../models/category_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/product_provider.dart';

class ProductFormScreen extends StatefulWidget {
  final ProductModel? product;
  const ProductFormScreen({super.key, this.product});
  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey     = GlobalKey<FormState>();
  final _nameCtrl    = TextEditingController();
  final _descCtrl    = TextEditingController();
  final _priceCtrl   = TextEditingController();
  final _stockCtrl   = TextEditingController();
  int? _catId;
  int? _modelId;
  List<Map<String, dynamic>> _models = [];
  bool _loading = false;

  bool get isEdit => widget.product != null;

  @override
  void initState() {
    super.initState();
    if (isEdit) {
      final p = widget.product!;
      _nameCtrl.text  = p.name;
      _descCtrl.text  = p.description ?? '';
      _priceCtrl.text = p.price.toString();
      _stockCtrl.text = p.stockQuantity.toString();
      _catId   = p.categoryId;
      _modelId = p.modelId;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose(); _descCtrl.dispose();
    _priceCtrl.dispose(); _stockCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadModels(int catId) async {
    final api = context.read<AuthProvider>().api;
    try {
      final res = await api.getModels(categoryId: catId);
      setState(() {
        _models  = (res['data'] as List<dynamic>)
            .map((e) => e as Map<String, dynamic>)
            .toList();
        _modelId = null;
      });
    } catch (_) {}
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);

    final api  = context.read<AuthProvider>().api;
    final prov = context.read<ProductProvider>();
    final data = {
      'category_id':    _catId,
      'model_id':       _modelId,
      'name':           _nameCtrl.text.trim(),
      'description':    _descCtrl.text.trim(),
      'price':          double.parse(_priceCtrl.text),
      'stock_quantity': int.parse(_stockCtrl.text),
    };

    bool ok;
    if (isEdit) {
      ok = await prov.updateProduct(api, widget.product!.id, data);
    } else {
      ok = await prov.createProduct(api, data);
    }

    setState(() => _loading = false);
    if (!mounted) return;
    if (ok) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(isEdit ? 'Product updated' : 'Product created'),
            backgroundColor: AppTheme.green),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(prov.error ?? 'Failed'), backgroundColor: AppTheme.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final categories = context.read<ProductProvider>().categories;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Product' : 'Add Product'),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Category
              DropdownButtonFormField<int>(
                value: _catId,
                decoration: const InputDecoration(labelText: 'Category *'),
                items: categories.map((c) =>
                    DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
                onChanged: (v) {
                  setState(() { _catId = v; _modelId = null; _models = []; });
                  if (v != null) _loadModels(v);
                },
                validator: (v) => v == null ? 'Required' : null,
              ),
              const SizedBox(height: 14),
              // Model
              DropdownButtonFormField<int>(
                value: _modelId,
                decoration: const InputDecoration(labelText: 'Model *'),
                items: _models.map((m) =>
                    DropdownMenuItem(value: m['id'] as int, child: Text(m['name'] as String))).toList(),
                onChanged: (v) => setState(() => _modelId = v),
                validator: (v) => v == null ? 'Required' : null,
              ),
              const SizedBox(height: 14),
              _tf('Product Name *', _nameCtrl, validator: (v) => v!.isEmpty ? 'Required' : null),
              const SizedBox(height: 14),
              _tf('Description', _descCtrl, maxLines: 2),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(child: _tf('Price *', _priceCtrl,
                    keyboard: TextInputType.number,
                    validator: (v) => v!.isEmpty ? 'Required' : null)),
                const SizedBox(width: 12),
                Expanded(child: _tf('Stock Qty *', _stockCtrl,
                    keyboard: TextInputType.number,
                    validator: (v) => v!.isEmpty ? 'Required' : null)),
              ]),
              const SizedBox(height: 28),
              _loading
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _save,
                      child: Text(isEdit ? 'Update Product' : 'Save Product'),
                    ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tf(String label, TextEditingController ctrl,
      {TextInputType? keyboard, int maxLines = 1, String? Function(String?)? validator}) {
    return TextFormField(
      controller: ctrl,
      keyboardType: keyboard,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label),
      validator: validator,
    );
  }
}

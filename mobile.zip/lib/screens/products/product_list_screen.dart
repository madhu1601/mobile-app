import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../../providers/product_provider.dart';
import '../../models/product_model.dart';
import '../cart/cart_screen.dart';
import 'product_form_screen.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});
  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  final _searchCtrl = TextEditingController();
  int? _selectedCatId;
  String _search = '';
  bool _initialLoaded = false;

  @override
  void initState() {
    super.initState();
    // Defer until the widget tree is ready and token is set
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final auth = context.read<AuthProvider>();
    // Wait until auth is ready
    if (!auth.isLoggedIn) return;
    await context.read<ProductProvider>().fetchAll(
          auth.api,
          categoryId: _selectedCatId,
          search: _search.isEmpty ? null : _search,
        );
    if (mounted) setState(() => _initialLoaded = true);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final productProv = context.watch<ProductProvider>();
    final cart        = context.watch<CartProvider>();
    final auth        = context.watch<AuthProvider>();
    final isAdmin     = auth.user?.isAdmin ?? false;
    final isCustomer  = auth.user?.isCustomer ?? false;

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('Available Models'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          if (isAdmin)
            IconButton(
              icon: const Icon(Icons.add_circle_outline, color: AppTheme.primary),
              onPressed: () async {
                await Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const ProductFormScreen()));
                _load(); // refresh after add
              },
            ),
        ],
      ),
      body: Column(
        children: [
          // ── Search + Category chips ─────────────────────────
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Column(
              children: [
                // Search bar
                TextField(
                  controller: _searchCtrl,
                  decoration: InputDecoration(
                    hintText: 'Search items...',
                    hintStyle: const TextStyle(color: Colors.grey, fontSize: 13),
                    prefixIcon: const Icon(Icons.search, color: Colors.grey, size: 20),
                    filled: true,
                    fillColor: const Color(0xFFF5F6FA),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                  onChanged: (v) {
                    setState(() => _search = v);
                    _load();
                  },
                ),
                const SizedBox(height: 10),
                // Category chips
                SizedBox(
                  height: 34,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _CategoryChip(
                        label: 'ALL',
                        selected: _selectedCatId == null,
                        onTap: () {
                          setState(() => _selectedCatId = null);
                          _load();
                        },
                      ),
                      ...productProv.categories.map((c) => _CategoryChip(
                            label: c.name,
                            selected: _selectedCatId == c.id,
                            onTap: () {
                              setState(() => _selectedCatId = c.id);
                              _load();
                            },
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Product list ────────────────────────────────────
          Expanded(
            child: productProv.loading && !_initialLoaded
                ? const Center(child: CircularProgressIndicator())
                : productProv.error != null
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.error_outline, size: 48, color: Colors.grey),
                            const SizedBox(height: 8),
                            Text(productProv.error!,
                                style: const TextStyle(color: Colors.grey),
                                textAlign: TextAlign.center),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: _load,
                              child: const Text('Retry'),
                            ),
                          ],
                        ),
                      )
                    : productProv.products.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.phone_android_outlined,
                                    size: 64, color: Colors.grey[300]),
                                const SizedBox(height: 12),
                                const Text('No products found.',
                                    style: TextStyle(color: Colors.grey)),
                                const SizedBox(height: 16),
                                ElevatedButton(
                                    onPressed: _load, child: const Text('Refresh')),
                              ],
                            ),
                          )
                        : RefreshIndicator(
                            onRefresh: _load,
                            child: ListView.builder(
                              padding: EdgeInsets.fromLTRB(
                                  16, 12, 16,
                                  // Extra bottom padding when cart bar is visible
                                  isCustomer && cart.totalItems > 0 ? 100 : 20),
                              itemCount: productProv.products.length,
                              itemBuilder: (ctx, i) {
                                final p = productProv.products[i];
                                return _ProductTile(
                                  product: p,
                                  inCart: cart.contains(p.id),
                                  isAdmin: isAdmin,
                                  isCustomer: isCustomer,
                                  onAdd: () {
                                    cart.addItem(p);
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(SnackBar(
                                      content: Text('${p.name} added to cart'),
                                      duration: const Duration(seconds: 1),
                                      backgroundColor: AppTheme.green,
                                    ));
                                  },
                                  onRemove: () => cart.removeItem(p.id),
                                  onEdit: () async {
                                    await Navigator.of(context).push(MaterialPageRoute(
                                        builder: (_) => ProductFormScreen(product: p)));
                                    _load();
                                  },
                                  onDelete: () async {
                                    final confirm = await showDialog<bool>(
                                      context: context,
                                      builder: (_) => AlertDialog(
                                        title: const Text('Deactivate Product'),
                                        content: Text('Deactivate "${p.name}"?'),
                                        actions: [
                                          TextButton(
                                              onPressed: () => Navigator.pop(context, false),
                                              child: const Text('Cancel')),
                                          TextButton(
                                              onPressed: () => Navigator.pop(context, true),
                                              child: const Text('Deactivate',
                                                  style: TextStyle(color: AppTheme.red))),
                                        ],
                                      ),
                                    );
                                    if (confirm == true && context.mounted) {
                                      await context
                                          .read<ProductProvider>()
                                          .deleteProduct(auth.api, p.id);
                                      _load();
                                    }
                                  },
                                );
                              },
                            ),
                          ),
          ),
        ],
      ),

      // ── Sticky bottom cart bar (customer only) ──────────────
      bottomSheet: isCustomer && cart.totalItems > 0
          ? _CartBottomBar(
              itemCount: cart.totalItems,
              totalPrice: cart.totalPrice,
              onViewCart: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const CartScreen())),
            )
          : null,
    );
  }
}

// ── Category chip ─────────────────────────────────────────────
class _CategoryChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _CategoryChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF1A237E) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? const Color(0xFF1A237E) : const Color(0xFFDDDDDD),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : Colors.black87,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

// ── Product tile ──────────────────────────────────────────────
class _ProductTile extends StatelessWidget {
  final ProductModel product;
  final bool inCart;
  final bool isAdmin;
  final bool isCustomer;
  final VoidCallback onAdd;
  final VoidCallback onRemove;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _ProductTile({
    required this.product,
    required this.inCart,
    required this.isAdmin,
    required this.isCustomer,
    required this.onAdd,
    required this.onRemove,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Name + price row
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name.toUpperCase(),
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      [
                        if (product.categoryName != null) product.categoryName!,
                        if (product.description != null && product.description!.isNotEmpty)
                          product.description!,
                      ].join(' • '),
                      style: const TextStyle(color: Colors.grey, fontSize: 11),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              // Price tag
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: AppTheme.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppTheme.green.withOpacity(0.4)),
                ),
                child: Text(
                  '₹${product.price.toStringAsFixed(2)}',
                  style: const TextStyle(
                      color: AppTheme.green, fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Stock + action row
          Row(
            children: [
              Text(
                'In stock: ${product.stockQuantity} QTY',
                style: const TextStyle(color: Colors.grey, fontSize: 11),
              ),
              const Spacer(),
              // Admin edit/delete buttons
              if (isAdmin) ...[
                _IconBtn(
                  icon: Icons.edit_outlined,
                  color: AppTheme.primary,
                  onTap: onEdit,
                ),
                const SizedBox(width: 6),
                _IconBtn(
                  icon: Icons.delete_outline,
                  color: AppTheme.red,
                  onTap: onDelete,
                ),
                const SizedBox(width: 8),
              ],
              // Add/Remove button (customer only)
              if (isCustomer)
                SizedBox(
                  width: 96,
                  height: 34,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: inCart ? AppTheme.red : const Color(0xFF1A237E),
                      foregroundColor: Colors.white,
                      minimumSize: Size.zero,
                      padding: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: product.inStock ? (inCart ? onRemove : onAdd) : null,
                    child: Text(
                      inCart ? 'Remove' : 'Add Item',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              if (!isCustomer && !isAdmin)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: product.inStock
                        ? AppTheme.green.withOpacity(0.1)
                        : AppTheme.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    product.inStock ? 'In Stock' : 'Out of Stock',
                    style: TextStyle(
                        color: product.inStock ? AppTheme.green : AppTheme.red,
                        fontSize: 11,
                        fontWeight: FontWeight.w600),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Icon(icon, size: 16, color: color),
      ),
    );
  }
}

// ── Cart bottom bar ───────────────────────────────────────────
class _CartBottomBar extends StatelessWidget {
  final int itemCount;
  final double totalPrice;
  final VoidCallback onViewCart;

  const _CartBottomBar({
    required this.itemCount,
    required this.totalPrice,
    required this.onViewCart,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: const BoxDecoration(
        color: Color(0xFF1A237E),
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 12, offset: Offset(0, -4))],
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Selected Items',
                  style: TextStyle(color: Colors.white70, fontSize: 11)),
              Text(
                '$itemCount item${itemCount > 1 ? 's' : ''}  •  ₹${totalPrice.toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const Spacer(),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF1A237E),
              minimumSize: Size.zero,
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              elevation: 0,
            ),
            onPressed: onViewCart,
            child: const Text('View Cart', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../../providers/product_provider.dart';
import '../../models/product_model.dart';
import '../cart/cart_screen.dart';
import 'product_form_screen.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});
  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  final _searchCtrl = TextEditingController();
  int? _selectedCatId;
  String _search = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final api = context.read<AuthProvider>().api;
    await context.read<ProductProvider>().fetchAll(api,
        categoryId: _selectedCatId, search: _search.isEmpty ? null : _search);
  }

  @override
  void dispose() { _searchCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final productProv = context.watch<ProductProvider>();
    final cart        = context.watch<CartProvider>();
    final auth        = context.watch<AuthProvider>();
    final isAdmin     = auth.user?.isAdmin ?? false;

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('Available Models'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          if (isAdmin)
            IconButton(
              icon: const Icon(Icons.add_circle_outline),
              onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const ProductFormScreen())),
            ),
        ],
      ),
      body: Column(
        children: [
          // ── Search + Category chips ─────────────────────────
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Column(
              children: [
                // Search
                TextField(
                  controller: _searchCtrl,
                  decoration: InputDecoration(
                    hintText: 'Search items...',
                    prefixIcon: const Icon(Icons.search, color: Colors.grey),
                    filled: true,
                    fillColor: const Color(0xFFF5F6FA),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                  onChanged: (v) {
                    setState(() => _search = v);
                    _load();
                  },
                ),
                const SizedBox(height: 10),
                // Category chips
                SizedBox(
                  height: 34,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _Chip('ALL', _selectedCatId == null, () {
                        setState(() => _selectedCatId = null);
                        _load();
                      }),
                      ...productProv.categories.map((c) => _Chip(
                            c.name,
                            _selectedCatId == c.id,
                            () {
                              setState(() => _selectedCatId = c.id);
                              _load();
                            },
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Product list ────────────────────────────────────
          Expanded(
            child: productProv.loading
                ? const Center(child: CircularProgressIndicator())
                : productProv.products.isEmpty
                    ? const Center(child: Text('No products found.', style: TextStyle(color: Colors.grey)))
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                          itemCount: productProv.products.length,
                          itemBuilder: (ctx, i) {
                            final p = productProv.products[i];
                            return _ProductTile(
                              product: p,
                              inCart: cart.contains(p.id),
                              isAdmin: isAdmin,
                              onAdd: () => cart.addItem(p),
                              onRemove: () => cart.removeItem(p.id),
                              onEdit: () => Navigator.of(context).push(
                                  MaterialPageRoute(builder: (_) => ProductFormScreen(product: p))),
                              onDelete: () async {
                                final ok = await context.read<ProductProvider>()
                                    .deleteProduct(auth.api, p.id);
                                if (ok && context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Product deactivated')));
                                }
                              },
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),

      // ── Sticky cart bar ─────────────────────────────────────
      bottomSheet: cart.totalItems > 0
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: const BoxDecoration(
                color: Color(0xFF1A237E),
                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: Row(
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Selected Items',
                          style: TextStyle(color: Colors.white70, fontSize: 11)),
                      Text('${cart.totalItems} items',
                          style: const TextStyle(
                              color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const Spacer(),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF1A237E),
                      minimumSize: Size.zero,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    onPressed: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const CartScreen())),
                    child: const Text('View Cart', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            )
          : null,
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _Chip(this.label, this.selected, this.onTap);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF1A237E) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: selected ? const Color(0xFF1A237E) : const Color(0xFFDDDDDD)),
        ),
        child: Text(label,
            style: TextStyle(
                color: selected ? Colors.white : Colors.black87,
                fontSize: 12,
                fontWeight: FontWeight.w500)),
      ),
    );
  }
}

class _ProductTile extends StatelessWidget {
  final ProductModel product;
  final bool inCart;
  final bool isAdmin;
  final VoidCallback onAdd;
  final VoidCallback onRemove;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const _ProductTile({
    required this.product, required this.inCart, required this.isAdmin,
    required this.onAdd, required this.onRemove, required this.onEdit, required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.name.toUpperCase(),
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(height: 3),
                    Text(
                      '${product.categoryName ?? ''} • ${product.description ?? 'Original Quality'}',
                      style: const TextStyle(color: Colors.grey, fontSize: 11),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              // Price tag
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: AppTheme.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppTheme.green.withOpacity(0.4)),
                ),
                child: Text('₹${product.price.toStringAsFixed(2)}',
                    style: const TextStyle(
                        color: AppTheme.green, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text('In stock: ${product.stockQuantity} QTY',
                  style: const TextStyle(color: Colors.grey, fontSize: 11)),
              const Spacer(),
              if (isAdmin) ...[
                GestureDetector(
                  onTap: onEdit,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(Icons.edit_outlined, size: 16, color: AppTheme.primary),
                  ),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: onDelete,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppTheme.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(Icons.delete_outline, size: 16, color: AppTheme.red),
                  ),
                ),
                const SizedBox(width: 8),
              ],
              SizedBox(
                width: 90,
                height: 32,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: inCart ? AppTheme.red : const Color(0xFF1A237E),
                    minimumSize: Size.zero,
                    padding: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    elevation: 0,
                  ),
                  onPressed: product.inStock ? (inCart ? onRemove : onAdd) : null,
                  child: Text(inCart ? 'Remove' : 'Add Item',
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

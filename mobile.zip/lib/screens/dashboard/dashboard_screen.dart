import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../providers/dashboard_provider.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final api = context.read<AuthProvider>().api;
    await context.read<DashboardProvider>().fetch(api);
  }

  @override
  Widget build(BuildContext context) {
    final auth  = context.watch<AuthProvider>();
    final dash  = context.watch<DashboardProvider>();
    final role  = auth.user?.role ?? '';
    final name  = auth.user?.name.split(' ').first ?? 'User';
    final fmt   = NumberFormat('#,##0.00', 'en_US');

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: Text('Welcome $name,'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _load,
          ),
        ],
      ),
      body: dash.loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ── Admin/Accountant stats ──────────────────
                    if (role == 'admin' || role == 'accountant') ...[
                      _AdminStats(dash: dash, fmt: fmt),
                      const SizedBox(height: 16),
                    ],

                    // ── Order stats (all roles) ─────────────────
                    _OrderStats(stats: dash.stats),
                    const SizedBox(height: 16),

                    // ── Low stock alert (admin) ─────────────────
                    if (role == 'admin') ...[
                      _LowStockAlert(lowStock: dash.extra['low_stock'] as List<dynamic>? ?? []),
                      const SizedBox(height: 16),
                    ],

                    // ── Top outstanding (admin/accountant) ──────
                    if ((role == 'admin' || role == 'accountant') &&
                        (dash.extra['top_outstanding'] as List<dynamic>? ?? []).isNotEmpty) ...[
                      _TopOutstanding(
                        items: dash.extra['top_outstanding'] as List<dynamic>,
                        fmt: fmt,
                      ),
                      const SizedBox(height: 16),
                    ],

                    // ── Recent orders ───────────────────────────
                    if (dash.recentOrders.isNotEmpty) ...[
                      const Text('Recent Orders',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      ...dash.recentOrders.map((o) => _RecentOrderTile(order: o)),
                    ],
                  ],
                ),
              ),
            ),
    );
  }
}

// ── Admin stat cards ──────────────────────────────────────────
class _AdminStats extends StatelessWidget {
  final DashboardProvider dash;
  final NumberFormat fmt;
  const _AdminStats({required this.dash, required this.fmt});

  @override
  Widget build(BuildContext context) {
    final extra = dash.extra;
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.6,
      children: [
        _MiniCard(
          icon: Icons.inventory_2_outlined,
          label: 'Total Products',
          value: '${extra['total_products'] ?? 0}',
          color: AppTheme.primary,
        ),
        _MiniCard(
          icon: Icons.people_outline,
          label: 'Total Clients',
          value: '${extra['total_customers'] ?? 0}',
          color: AppTheme.teal,
        ),
        _MiniCard(
          icon: Icons.hourglass_empty,
          label: 'Pending Orders',
          value: '${dash.stats['pending'] ?? 0}',
          color: AppTheme.orange,
        ),
        _MiniCard(
          icon: Icons.account_balance_wallet_outlined,
          label: 'Total Outstanding',
          value: '₹${fmt.format(extra['total_outstanding'] ?? 0)}',
          valueColor: AppTheme.red,
          color: AppTheme.red,
        ),
      ],
    );
  }
}

class _MiniCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final Color? valueColor;
  const _MiniCard({required this.icon, required this.label, required this.value, required this.color, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(width: 6),
            Expanded(child: Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey), overflow: TextOverflow.ellipsis)),
          ]),
          const Spacer(),
          Text(value,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: valueColor ?? Colors.black87)),
        ],
      ),
    );
  }
}

// ── Order stats row ───────────────────────────────────────────
class _OrderStats extends StatelessWidget {
  final Map<String, dynamic> stats;
  const _OrderStats({required this.stats});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _StatChip('Total', '${stats['total'] ?? 0}', AppTheme.primary)),
        const SizedBox(width: 8),
        Expanded(child: _StatChip('Done', '${stats['completed'] ?? 0}', AppTheme.green)),
        const SizedBox(width: 8),
        Expanded(child: _StatChip('Pending', '${stats['pending'] ?? 0}', AppTheme.orange)),
        const SizedBox(width: 8),
        Expanded(child: _StatChip('Rejected', '${stats['rejected'] ?? 0}', AppTheme.red)),
      ],
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatChip(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
        ],
      ),
    );
  }
}

// ── Low stock alert ───────────────────────────────────────────
class _LowStockAlert extends StatefulWidget {
  final List<dynamic> lowStock;
  const _LowStockAlert({required this.lowStock});
  @override
  State<_LowStockAlert> createState() => _LowStockAlertState();
}

class _LowStockAlertState extends State<_LowStockAlert> {
  bool _visible = true;

  @override
  Widget build(BuildContext context) {
    if (!_visible || widget.lowStock.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF8E1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFCC02)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.warning_amber_rounded, color: Color(0xFFF57C00), size: 18),
              const SizedBox(width: 8),
              const Expanded(
                child: Text('Low Stock Alert',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFF57C00))),
              ),
              GestureDetector(
                onTap: () => setState(() => _visible = false),
                child: const Icon(Icons.close, size: 16, color: Colors.grey),
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Text('Few items in your inventory will go out of stock soon.',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
          const SizedBox(height: 8),
          const Text('View Items',
              style: TextStyle(color: Color(0xFFF57C00), fontWeight: FontWeight.w600, fontSize: 12)),
        ],
      ),
    );
  }
}

// ── Top outstanding ───────────────────────────────────────────
class _TopOutstanding extends StatelessWidget {
  final List<dynamic> items;
  final NumberFormat fmt;
  const _TopOutstanding({required this.items, required this.fmt});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Top Outstanding',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...items.map((item) => _OutstandingCard(item: item as Map<String, dynamic>, fmt: fmt)),
      ],
    );
  }
}

class _OutstandingCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final NumberFormat fmt;
  const _OutstandingCard({required this.item, required this.fmt});

  @override
  Widget build(BuildContext context) {
    final outstanding = double.parse(item['outstanding'].toString());
    final totalBuy    = double.parse(item['total_buy'].toString());
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['name'] as String,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    const SizedBox(height: 2),
                    Text('Total Buy: ₹${fmt.format(totalBuy)}',
                        style: const TextStyle(fontSize: 11, color: Colors.grey)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: AppTheme.red.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppTheme.red.withOpacity(0.3)),
                ),
                child: Text('₹${fmt.format(outstanding)}',
                    style: const TextStyle(color: AppTheme.red, fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.notifications_outlined, size: 16),
                  label: const Text('Remind', style: TextStyle(fontSize: 12)),
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.call, size: 16),
                  label: const Text('Call', style: TextStyle(fontSize: 12)),
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1A237E),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    minimumSize: Size.zero,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Recent order tile ─────────────────────────────────────────
class _RecentOrderTile extends StatelessWidget {
  final dynamic order;
  const _RecentOrderTile({required this.order});

  @override
  Widget build(BuildContext context) {
    final status = order['status'] as String;
    final colors = {
      'pending': AppTheme.orange, 'completed': AppTheme.green,
      'rejected': AppTheme.red, 'assigned': AppTheme.primary,
    };
    final color = colors[status] ?? Colors.grey;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
      ),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), shape: BoxShape.circle),
            child: const Icon(Icons.receipt_long, color: AppTheme.primary, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(order['order_number'] as String,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                Text(order['customer_name'] as String,
                    style: const TextStyle(color: Colors.grey, fontSize: 11)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('₹${double.parse(order['total_amount'].toString()).toStringAsFixed(0)}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(status.toUpperCase(),
                    style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

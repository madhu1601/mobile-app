import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../dashboard/dashboard_screen.dart';
import '../products/product_list_screen.dart';
import '../cart/cart_screen.dart';
import '../orders/orders_screen.dart';
import '../notifications/notifications_screen.dart';
import '../profile/profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  // Allow other screens to jump to a specific tab
  void jumpTo(int index) => setState(() => _index = index);

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final cart = context.watch<CartProvider>();
    final role = auth.user?.role ?? '';

    final navDefs = _buildNav(role);

    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: navDefs.map((n) => n.page).toList(),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        backgroundColor: Colors.white,
        indicatorColor: AppTheme.primary.withOpacity(0.12),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        destinations: navDefs.map((n) {
          // Cart icon with badge
          final isCart = n.label == 'Cart';
          final iconWidget = isCart && cart.totalItems > 0
              ? Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Icon(n.icon),
                    Positioned(
                      right: -6,
                      top: -4,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: const BoxDecoration(
                            color: AppTheme.red, shape: BoxShape.circle),
                        child: Text(
                          '${cart.totalItems}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 8,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                )
              : Icon(n.icon);

          return NavigationDestination(
            icon: iconWidget,
            selectedIcon: Icon(n.selectedIcon, color: AppTheme.primary),
            label: n.label,
          );
        }).toList(),
      ),
    );
  }

  List<_NavDef> _buildNav(String role) {
    // Dashboard is always first
    final nav = <_NavDef>[
      _NavDef(Icons.dashboard_outlined, Icons.dashboard,
          'Dashboard', const DashboardScreen()),
    ];

    // Products tab – visible to customer AND admin
    if (role == 'customer' || role == 'admin') {
      nav.add(_NavDef(Icons.phone_android_outlined, Icons.phone_android,
          'Products', const ProductListScreen()));
    }

    // Cart tab – customer only
    if (role == 'customer') {
      nav.add(_NavDef(Icons.shopping_cart_outlined, Icons.shopping_cart,
          'Cart', const CartScreen()));
    }

    // Orders – all roles
    nav.add(_NavDef(Icons.receipt_long_outlined, Icons.receipt_long,
        'Orders', const OrdersScreen()));

    // Notifications
    nav.add(_NavDef(Icons.notifications_outlined, Icons.notifications,
        'Alerts', const NotificationsScreen()));

    // Profile
    nav.add(_NavDef(Icons.person_outline, Icons.person,
        'Profile', const ProfileScreen()));

    return nav;
  }
}

class _NavDef {
  final IconData icon;
  final IconData selectedIcon;
  final String label;
  final Widget page;
  const _NavDef(this.icon, this.selectedIcon, this.label, this.page);
}

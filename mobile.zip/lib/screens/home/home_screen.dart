import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../auth/login_screen.dart';
import '../dashboard/dashboard_screen.dart';
import '../products/product_list_screen.dart';
import '../orders/orders_screen.dart';
import '../notifications/notifications_screen.dart';
import '../profile/profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final cart = context.watch<CartProvider>();
    final role = auth.user?.role ?? '';

    // Build nav items based on role
    final List<_NavDef> navDefs = _buildNav(role);
    final pages = navDefs.map((n) => n.page).toList();

    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        backgroundColor: Colors.white,
        indicatorColor: AppTheme.primary.withOpacity(0.12),
        destinations: navDefs.map((n) {
          Widget icon = n.label == 'Cart'
              ? Stack(children: [
                  Icon(n.icon),
                  if (cart.totalItems > 0)
                    Positioned(
                      right: 0, top: 0,
                      child: Container(
                        width: 14, height: 14,
                        decoration: const BoxDecoration(
                            color: AppTheme.red, shape: BoxShape.circle),
                        child: Center(
                          child: Text('${cart.totalItems}',
                              style: const TextStyle(color: Colors.white, fontSize: 8)),
                        ),
                      ),
                    ),
                ])
              : Icon(n.icon);
          return NavigationDestination(
            icon: icon,
            selectedIcon: Icon(n.selectedIcon, color: AppTheme.primary),
            label: n.label,
          );
        }).toList(),
      ),
    );
  }

  List<_NavDef> _buildNav(String role) {
    final base = [
      _NavDef(Icons.dashboard_outlined, Icons.dashboard, 'Dashboard', const DashboardScreen()),
    ];

    if (role == 'customer') {
      base.addAll([
        _NavDef(Icons.phone_android_outlined, Icons.phone_android, 'Products', const ProductListScreen()),
        _NavDef(Icons.shopping_cart_outlined, Icons.shopping_cart, 'Cart', const ProductListScreen()),
        _NavDef(Icons.receipt_long_outlined, Icons.receipt_long, 'Orders', const OrdersScreen()),
      ]);
    } else {
      base.addAll([
        _NavDef(Icons.receipt_long_outlined, Icons.receipt_long, 'Orders', const OrdersScreen()),
      ]);
      if (role == 'admin') {
        base.add(_NavDef(Icons.phone_android_outlined, Icons.phone_android, 'Products', const ProductListScreen()));
      }
    }

    base.addAll([
      _NavDef(Icons.notifications_outlined, Icons.notifications, 'Alerts', const NotificationsScreen()),
      _NavDef(Icons.person_outline, Icons.person, 'Profile', const ProfileScreen()),
    ]);

    return base;
  }
}

class _NavDef {
  final IconData icon;
  final IconData selectedIcon;
  final String label;
  final Widget page;
  _NavDef(this.icon, this.selectedIcon, this.label, this.page);
}

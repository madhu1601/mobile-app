import 'package:flutter/foundation.dart';
import '../core/api_service.dart';
import '../models/product_model.dart';
import '../models/category_model.dart';

class ProductProvider extends ChangeNotifier {
  List<ProductModel>  _products   = [];
  List<CategoryModel> _categories = [];
  bool    _loading = false;
  String? _error;

  List<ProductModel>  get products   => _products;
  List<CategoryModel> get categories => _categories;
  bool    get loading => _loading;
  String? get error   => _error;

  Future<void> fetchAll(ApiService api, {int? categoryId, String? search}) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final results = await Future.wait([
        api.getProducts(categoryId: categoryId, search: search),
        api.getCategories(),
      ]);
      _products   = (results[0]['data'] as List<dynamic>)
          .map((e) => ProductModel.fromJson(e as Map<String, dynamic>))
          .toList();
      _categories = (results[1]['data'] as List<dynamic>)
          .map((e) => CategoryModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } on ApiException catch (e) {
      _error = e.message;
    } catch (_) {
      _error = 'Failed to load products.';
    } finally {
      _loading = false; notifyListeners();
    }
  }

  Future<void> fetchProducts(ApiService api, {int? categoryId, String? search}) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final res = await api.getProducts(categoryId: categoryId, search: search);
      _products = (res['data'] as List<dynamic>)
          .map((e) => ProductModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _loading = false; notifyListeners();
    }
  }

  Future<bool> createProduct(ApiService api, Map<String, dynamic> data) async {
    try {
      await api.createProduct(data);
      await fetchProducts(api);
      return true;
    } on ApiException catch (e) {
      _error = e.message; notifyListeners(); return false;
    }
  }

  Future<bool> updateProduct(ApiService api, int id, Map<String, dynamic> data) async {
    try {
      await api.updateProduct(id, data);
      await fetchProducts(api);
      return true;
    } on ApiException catch (e) {
      _error = e.message; notifyListeners(); return false;
    }
  }

  Future<bool> deleteProduct(ApiService api, int id) async {
    try {
      await api.deleteProduct(id);
      _products.removeWhere((p) => p.id == id);
      notifyListeners(); return true;
    } on ApiException catch (e) {
      _error = e.message; notifyListeners(); return false;
    }
  }
}

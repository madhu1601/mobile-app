import 'package:flutter/foundation.dart';
import '../core/api_service.dart';

class DashboardProvider extends ChangeNotifier {
  Map<String, dynamic>? _data;
  bool    _loading = false;
  String? _error;

  Map<String, dynamic>? get data    => _data;
  bool    get loading => _loading;
  String? get error   => _error;

  Map<String, dynamic> get stats => (_data?['stats'] as Map<String, dynamic>?) ?? {};
  Map<String, dynamic> get extra => (_data?['extra'] as Map<String, dynamic>?) ?? {};
  List<dynamic> get recentOrders => (_data?['recent_orders'] as List<dynamic>?) ?? [];

  Future<void> fetch(ApiService api) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final res = await api.getDashboard();
      _data = res['data'] as Map<String, dynamic>;
    } on ApiException catch (e) {
      _error = e.message;
    } catch (_) {
      _error = 'Failed to load dashboard.';
    } finally {
      _loading = false; notifyListeners();
    }
  }
}

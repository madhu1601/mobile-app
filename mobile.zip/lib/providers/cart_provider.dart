import 'package:flutter/foundation.dart';
import '../models/cart_item_model.dart';
import '../models/product_model.dart';

class CartProvider extends ChangeNotifier {
  final Map<int, CartItem> _items = {};

  List<CartItem> get items      => _items.values.toList();
  int    get totalItems         => _items.values.fold(0, (s, i) => s + i.quantity);
  double get totalPrice         => _items.values.fold(0.0, (s, i) => s + i.subtotal);
  bool   contains(int id)       => _items.containsKey(id);

  void addItem(ProductModel product) {
    if (_items.containsKey(product.id)) {
      _items[product.id]!.quantity++;
    } else {
      _items[product.id] = CartItem(product: product);
    }
    notifyListeners();
  }

  void removeItem(int productId) {
    _items.remove(productId);
    notifyListeners();
  }

  void increment(int productId) {
    if (_items.containsKey(productId)) {
      _items[productId]!.quantity++;
      notifyListeners();
    }
  }

  void decrement(int productId) {
    if (_items.containsKey(productId)) {
      if (_items[productId]!.quantity > 1) {
        _items[productId]!.quantity--;
      } else {
        _items.remove(productId);
      }
      notifyListeners();
    }
  }

  void clear() { _items.clear(); notifyListeners(); }

  List<Map<String, dynamic>> toPayload() => _items.values
      .map((i) => {'product_id': i.product.id, 'quantity': i.quantity})
      .toList();
}

import 'package:flutter/foundation.dart';
import '../core/api_service.dart';
import '../models/order_model.dart';

class OrderProvider extends ChangeNotifier {
  List<OrderModel> _orders    = [];
  OrderModel?      _current;
  bool    _loading = false;
  String? _error;

  List<OrderModel> get orders  => _orders;
  OrderModel?      get current => _current;
  bool    get loading => _loading;
  String? get error   => _error;

  Future<void> fetchOrders(ApiService api, {String? status}) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final res = await api.getOrders(status: status);
      _orders = (res['data'] as List<dynamic>)
          .map((e) => OrderModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _loading = false; notifyListeners();
    }
  }

  Future<void> fetchOrder(ApiService api, int id) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final res  = await api.getOrder(id);
      final data = res['data'] as Map<String, dynamic>;
      final order = OrderModel.fromJson(data['order'] as Map<String, dynamic>);
      // Attach items + history
      final items = (data['items'] as List<dynamic>)
          .map((e) => OrderItemModel.fromJson(e as Map<String, dynamic>))
          .toList();
      final history = (data['history'] as List<dynamic>)
          .map((e) => OrderHistoryModel.fromJson(e as Map<String, dynamic>))
          .toList();
      _current = OrderModel(
        id: order.id, orderNumber: order.orderNumber,
        customerId: order.customerId, customerName: order.customerName,
        customerMobile: order.customerMobile,
        makerName: order.makerName, checkerName: order.checkerName,
        totalAmount: order.totalAmount, paidAmount: order.paidAmount,
        status: order.status, notes: order.notes, createdAt: order.createdAt,
        items: items, history: history,
      );
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _loading = false; notifyListeners();
    }
  }

  Future<OrderModel?> placeOrder(ApiService api, List<Map<String, dynamic>> items, {String? notes}) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final res   = await api.placeOrder(items, notes: notes);
      final data  = res['data'] as Map<String, dynamic>;
      final order = OrderModel.fromJson(data['order'] as Map<String, dynamic>);
      _orders.insert(0, order);
      notifyListeners();
      return order;
    } on ApiException catch (e) {
      _error = e.message; notifyListeners(); return null;
    } finally {
      _loading = false; notifyListeners();
    }
  }

  Future<bool> updateStatus(ApiService api, int orderId, String status, {String? remarks}) async {
    try {
      await api.updateOrderStatus(orderId, status, remarks: remarks);
      await fetchOrder(api, orderId);
      return true;
    } on ApiException catch (e) {
      _error = e.message; notifyListeners(); return false;
    }
  }

  Future<bool> assignOrder(ApiService api, int orderId, int makerId, int checkerId) async {
    try {
      await api.assignOrder(orderId, makerId, checkerId);
      await fetchOrder(api, orderId);
      return true;
    } on ApiException catch (e) {
      _error = e.message; notifyListeners(); return false;
    }
  }

  Future<bool> editItem(ApiService api, int itemId, int qty) async {
    try {
      await api.editOrderItem(itemId, qty);
      if (_current != null) await fetchOrder(api, _current!.id);
      return true;
    } on ApiException catch (e) {
      _error = e.message; notifyListeners(); return false;
    }
  }

  Future<bool> deleteItem(ApiService api, int itemId) async {
    try {
      await api.deleteOrderItem(itemId);
      if (_current != null) await fetchOrder(api, _current!.id);
      return true;
    } on ApiException catch (e) {
      _error = e.message; notifyListeners(); return false;
    }
  }
}

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/api_service.dart';
import '../core/notification_service.dart';
import '../models/user_model.dart';

class AuthProvider extends ChangeNotifier {
  final ApiService _api = ApiService();

  UserModel? _user;
  bool    _loading = false;
  String? _error;

  UserModel? get user    => _user;
  bool       get loading => _loading;
  String?    get error   => _error;
  bool       get isLoggedIn => _user != null;
  ApiService get api     => _api;

  // ── Restore session on app start ─────────────────────────────
  Future<void> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    if (token == null) return;

    _api.setToken(token);

    try {
      // Validate token by hitting dashboard
      await _api.getDashboard();

      // Token valid – restore user from prefs
      _user = UserModel(
        id:     prefs.getInt('user_id')     ?? 0,
        name:   prefs.getString('user_name')    ?? '',
        email:  prefs.getString('user_email'),
        mobile: prefs.getString('user_mobile'),
        role:   prefs.getString('user_role')    ?? '',
        roleId: prefs.getInt('user_role_id')    ?? 0,
      );
      // Re-register FCM token (may have changed)
      NotificationService().getAndSaveToken(_api).catchError((_) {});
      notifyListeners();
    } catch (_) {
      // Token expired or invalid
      await _clearPrefs();
      _api.setToken(null);
    }
  }

  // ── Login ─────────────────────────────────────────────────────
  Future<bool> login(String identifier, String password) async {
    _setLoading(true);
    _error = null;
    try {
      final res  = await _api.login(identifier, password);
      final data = res['data'] as Map<String, dynamic>;
      await _saveSession(data);
      return true;
    } on ApiException catch (e) {
      _error = e.message;
      notifyListeners();
      return false;
    } catch (e) {
      _error = 'Connection error. Check your internet.';
      notifyListeners();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // ── Register ──────────────────────────────────────────────────
  Future<bool> register(Map<String, dynamic> data) async {
    _setLoading(true);
    _error = null;
    try {
      final res     = await _api.register(data);
      final resData = res['data'] as Map<String, dynamic>;
      await _saveSession(resData);
      return true;
    } on ApiException catch (e) {
      _error = e.message;
      notifyListeners();
      return false;
    } catch (e) {
      _error = 'Connection error. Check your internet.';
      notifyListeners();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // ── Logout ────────────────────────────────────────────────────
  Future<void> logout() async {
    try { await _api.logout(); } catch (_) {}
    await _clearPrefs();
    _user = null;
    _api.setToken(null);
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  // ── Helpers ───────────────────────────────────────────────────
  Future<void> _saveSession(Map<String, dynamic> data) async {
    final token = data['token'] as String;
    final userMap = data['user'] as Map<String, dynamic>;
    _user = UserModel.fromJson(userMap);
    _api.setToken(token);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token',  token);
    await prefs.setInt('user_id',        _user!.id);
    await prefs.setString('user_name',   _user!.name);
    await prefs.setString('user_email',  _user!.email  ?? '');
    await prefs.setString('user_mobile', _user!.mobile ?? '');
    await prefs.setString('user_role',   _user!.role);
    await prefs.setInt('user_role_id',   _user!.roleId);

    // ── Save FCM token to backend ─────────────────────────────
    // Do this in background – don't block login
    NotificationService().getAndSaveToken(_api).catchError((_) {});

    notifyListeners();
  }

  Future<void> _clearPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  void _setLoading(bool v) {
    _loading = v;
    notifyListeners();
  }
}

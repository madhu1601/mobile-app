class CategoryModel {
  final int id;
  final String name;
  final bool isActive;

  const CategoryModel({required this.id, required this.name, this.isActive = true});

  factory CategoryModel.fromJson(Map<String, dynamic> j) => CategoryModel(
        id:       j['id'] as int,
        name:     j['name'] as String,
        isActive: (j['is_active'] as int? ?? 1) == 1,
      );
}

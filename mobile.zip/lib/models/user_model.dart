class UserModel {
  final int id;
  final String name;
  final String? email;
  final String? mobile;
  final String role;
  final int roleId;

  const UserModel({
    required this.id,
    required this.name,
    this.email,
    this.mobile,
    required this.role,
    required this.roleId,
  });

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
        id:     j['id'] as int,
        name:   j['name'] as String,
        email:  j['email'] as String?,
        mobile: j['mobile'] as String?,
        role:   j['role'] as String? ?? '',
        roleId: j['role_id'] as int? ?? 0,
      );

  bool get isAdmin     => role == 'admin';
  bool get isCustomer  => role == 'customer';
  bool get isMaker     => role == 'maker';
  bool get isChecker   => role == 'checker';
  bool get isAccountant=> role == 'accountant';
}

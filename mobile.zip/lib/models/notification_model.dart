class NotificationModel {
  final int id;
  final String title;
  final String? body;
  final bool isRead;
  final String createdAt;

  const NotificationModel({
    required this.id,
    required this.title,
    this.body,
    required this.isRead,
    required this.createdAt,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> j) => NotificationModel(
        id:        j['id'] as int,
        title:     j['title'] as String,
        body:      j['body'] as String?,
        isRead:    (j['is_read'] as int? ?? 0) == 1,
        createdAt: j['created_at'] as String,
      );
}

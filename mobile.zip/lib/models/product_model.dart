class ProductModel {
  final int id;
  final String name;
  final String? description;
  final double price;
  final int stockQuantity;
  final String? imageUrl;
  final String? categoryName;
  final String? modelName;
  final int categoryId;
  final int modelId;
  final bool isActive;

  const ProductModel({
    required this.id,
    required this.name,
    this.description,
    required this.price,
    required this.stockQuantity,
    this.imageUrl,
    this.categoryName,
    this.modelName,
    required this.categoryId,
    required this.modelId,
    this.isActive = true,
  });

  factory ProductModel.fromJson(Map<String, dynamic> j) => ProductModel(
        id:            j['id'] as int,
        name:          j['name'] as String,
        description:   j['description'] as String?,
        price:         double.parse(j['price'].toString()),
        stockQuantity: j['stock_quantity'] as int,
        imageUrl:      j['image_url'] as String?,
        categoryName:  j['category_name'] as String?,
        modelName:     j['model_name'] as String?,
        categoryId:    j['category_id'] as int? ?? 0,
        modelId:       j['model_id'] as int? ?? 0,
        isActive:      (j['is_active'] as int? ?? 1) == 1,
      );

  bool get inStock => stockQuantity > 0;
}

class OrderItemModel {
  final int id;
  final int productId;
  final String productName;
  final String? imageUrl;
  final int quantity;
  final double unitPrice;
  final double subtotal;

  const OrderItemModel({
    required this.id,
    required this.productId,
    required this.productName,
    this.imageUrl,
    required this.quantity,
    required this.unitPrice,
    required this.subtotal,
  });

  factory OrderItemModel.fromJson(Map<String, dynamic> j) => OrderItemModel(
        id:          j['id'] as int,
        productId:   j['product_id'] as int,
        productName: j['product_name'] as String,
        imageUrl:    j['image_url'] as String?,
        quantity:    j['quantity'] as int,
        unitPrice:   double.parse(j['unit_price'].toString()),
        subtotal:    double.parse(j['subtotal'].toString()),
      );
}

class OrderHistoryModel {
  final int id;
  final String userName;
  final String roleLabel;
  final String? fromStatus;
  final String? toStatus;
  final String? remarks;
  final String createdAt;

  const OrderHistoryModel({
    required this.id,
    required this.userName,
    required this.roleLabel,
    this.fromStatus,
    this.toStatus,
    this.remarks,
    required this.createdAt,
  });

  factory OrderHistoryModel.fromJson(Map<String, dynamic> j) => OrderHistoryModel(
        id:         j['id'] as int,
        userName:   j['user_name'] as String,
        roleLabel:  j['role_label'] as String,
        fromStatus: j['from_status'] as String?,
        toStatus:   j['to_status'] as String?,
        remarks:    j['remarks'] as String?,
        createdAt:  j['created_at'] as String,
      );
}

class OrderModel {
  final int id;
  final String orderNumber;
  final int customerId;
  final String customerName;
  final String? customerMobile;
  final String? makerName;
  final String? checkerName;
  final double totalAmount;
  final double paidAmount;
  final String status;
  final String? notes;
  final String createdAt;
  final List<OrderItemModel> items;
  final List<OrderHistoryModel> history;

  const OrderModel({
    required this.id,
    required this.orderNumber,
    required this.customerId,
    required this.customerName,
    this.customerMobile,
    this.makerName,
    this.checkerName,
    required this.totalAmount,
    required this.paidAmount,
    required this.status,
    this.notes,
    required this.createdAt,
    this.items = const [],
    this.history = const [],
  });

  factory OrderModel.fromJson(Map<String, dynamic> j) => OrderModel(
        id:             j['id'] as int,
        orderNumber:    j['order_number'] as String,
        customerId:     j['customer_id'] as int,
        customerName:   j['customer_name'] as String? ?? '',
        customerMobile: j['customer_mobile'] as String?,
        makerName:      j['maker_name'] as String?,
        checkerName:    j['checker_name'] as String?,
        totalAmount:    double.parse(j['total_amount'].toString()),
        paidAmount:     double.parse(j['paid_amount'].toString()),
        status:         j['status'] as String,
        notes:          j['notes'] as String?,
        createdAt:      j['created_at'] as String,
        items: (j['items'] as List<dynamic>? ?? [])
            .map((e) => OrderItemModel.fromJson(e as Map<String, dynamic>))
            .toList(),
        history: (j['history'] as List<dynamic>? ?? [])
            .map((e) => OrderHistoryModel.fromJson(e as Map<String, dynamic>))
            .toList(),
      );

  double get balance => totalAmount - paidAmount;

  String get statusLabel => status.replaceAll('_', ' ').toUpperCase();
}

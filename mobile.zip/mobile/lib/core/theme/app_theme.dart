import 'package:flutter/material.dart';

class AppTheme {
  static const Color primary = Color(0xFF0A73FF);
  static const Color error = Colors.red;

  // ✅ ADD THESE (missing ones)
  static const Color navyBg = Color(0xFF0B1E3C);

  static const Color cardOrange = Color(0xFFFFA726);
  static const Color cardTeal   = Color(0xFF26A69A);
  static const Color cardGreen  = Color(0xFF66BB6A);
  static const Color cardRed    = Color(0xFFEF5350);

  static const Color bottomBar = Color(0xFF1E88E5);

  static const Color priceTag = Color(0xFFFB8C00);

  static const Color addBtn    = Color(0xFF43A047);
  static const Color removeBtn = Color(0xFFE53935);

  // optional (safe)
  static const Color surface = Colors.white;
}
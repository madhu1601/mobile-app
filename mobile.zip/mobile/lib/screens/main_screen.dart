import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../main.dart';
import '../providers/auth_provider.dart';
import '../providers/order_provider.dart';
import '../providers/product_provider.dart';
import '../screens/splash_screen.dart';
import 'auth/login_screen.dart';
import 'dashboard/dashboard_screen.dart';
import 'products/product_list_screen.dart';
import 'orders/orders_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  bool _cartExpanded = true;

  final List<_NavItem> _navItems = [
    _NavItem(icon: Icons.home_outlined,         label: 'Dashboard'),
    _NavItem(icon: Icons.shopping_cart_outlined, label: 'Shopping Cart', hasChildren: true),
    _NavItem(icon: Icons.people_outline,         label: 'Users'),
    _NavItem(icon: Icons.person_outline,         label: 'Customers'),
    _NavItem(icon: Icons.inventory_2_outlined,   label: 'Products'),
    _NavItem(icon: Icons.category_outlined,      label: 'Category'),
    _NavItem(icon: Icons.phone_android_outlined, label: 'Model'),
    _NavItem(icon: Icons.account_balance_wallet_outlined, label: 'Accounts'),
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final api = context.read<AuthProvider>().apiService;
    await Future.wait([
      context.read<ProductProvider>().fetchProducts(api),
      context.read<OrderProvider>().fetchOrders(api),
    ]);
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 0:
        return const DashboardScreen();
      case 1:
        return const ProductListScreen(); // Available Models
      case 6:
        return const OrdersScreen();      // View Orders
      default:
        return _ComingSoon(label: _navItems[_selectedIndex].label);
    }
  }

  String _getTitle() {
    switch (_selectedIndex) {
      case 0:  return 'Dashboard';
      case 1:  return 'Available Models';
      case 6:  return 'View Orders';
      default: return _navItems[_selectedIndex].label;
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      body: Row(
        children: [
          // ── Sidebar ──────────────────────────────────────────
          Container(
            width: 220,
            color: AppTheme.sidebarBg,
            child: Column(
              children: [
                // Top bar with hamburger + logo
                Container(
                  height: 56,
                  color: AppTheme.navyBg,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      const Icon(Icons.menu, color: Colors.white, size: 22),
                      const SizedBox(width: 12),
                      const MDTelecomLogo(size: 36),
                    ],
                  ),
                ),
                // User info
                Container(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 20,
                        backgroundColor: Colors.grey[600],
                        child: const Icon(Icons.person,
                            color: Colors.white, size: 22),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              auth.user?.name ?? 'Admin',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const Text('Dept Admin',
                                style: TextStyle(
                                    color: Colors.grey, fontSize: 11)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(color: Colors.white12, height: 1),
                // Nav items
                Expanded(
                  child: ListView(
                    padding: EdgeInsets.zero,
                    children: [
                      _SidebarItem(
                        icon: Icons.home_outlined,
                        label: 'Dashboard',
                        selected: _selectedIndex == 0,
                        onTap: () => setState(() => _selectedIndex = 0),
                      ),
                      // Shopping Cart with sub-items
                      _SidebarItem(
                        icon: Icons.shopping_cart_outlined,
                        label: 'Shopping Cart',
                        selected: _selectedIndex == 1 || _selectedIndex == 6,
                        trailing: Icon(
                          _cartExpanded
                              ? Icons.keyboard_arrow_up
                              : Icons.keyboard_arrow_down,
                          color: Colors.white54,
                          size: 18,
                        ),
                        onTap: () =>
                            setState(() => _cartExpanded = !_cartExpanded),
                      ),
                      if (_cartExpanded) ...[
                        _SidebarSubItem(
                          label: 'Available Models',
                          selected: _selectedIndex == 1,
                          onTap: () => setState(() => _selectedIndex = 1),
                        ),
                        _SidebarSubItem(
                          label: 'View Orders',
                          selected: _selectedIndex == 6,
                          onTap: () => setState(() => _selectedIndex = 6),
                        ),
                      ],
                      _SidebarItem(
                        icon: Icons.people_outline,
                        label: 'Users',
                        selected: _selectedIndex == 2,
                        trailing: const Icon(Icons.keyboard_arrow_right,
                            color: Colors.white54, size: 18),
                        onTap: () => setState(() => _selectedIndex = 2),
                      ),
                      _SidebarItem(
                        icon: Icons.person_outline,
                        label: 'Customers',
                        selected: _selectedIndex == 3,
                        trailing: const Icon(Icons.keyboard_arrow_right,
                            color: Colors.white54, size: 18),
                        onTap: () => setState(() => _selectedIndex = 3),
                      ),
                      _SidebarItem(
                        icon: Icons.inventory_2_outlined,
                        label: 'Products',
                        selected: _selectedIndex == 4,
                        trailing: const Icon(Icons.keyboard_arrow_right,
                            color: Colors.white54, size: 18),
                        onTap: () => setState(() => _selectedIndex = 4),
                      ),
                      _SidebarItem(
                        icon: Icons.category_outlined,
                        label: 'Category',
                        selected: _selectedIndex == 5,
                        trailing: const Icon(Icons.keyboard_arrow_right,
                            color: Colors.white54, size: 18),
                        onTap: () => setState(() => _selectedIndex = 5),
                      ),
                      _SidebarItem(
                        icon: Icons.phone_android_outlined,
                        label: 'Model',
                        selected: _selectedIndex == 7,
                        trailing: const Icon(Icons.keyboard_arrow_right,
                            color: Colors.white54, size: 18),
                        onTap: () => setState(() => _selectedIndex = 7),
                      ),
                      _SidebarItem(
                        icon: Icons.account_balance_wallet_outlined,
                        label: 'Accounts',
                        selected: _selectedIndex == 8,
                        trailing: const Icon(Icons.keyboard_arrow_right,
                            color: Colors.white54, size: 18),
                        onTap: () => setState(() => _selectedIndex = 8),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // ── Main Content ─────────────────────────────────────
          Expanded(
            child: Column(
              children: [
                // Top app bar
                Container(
                  height: 56,
                  color: AppTheme.navyBg,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      const MDTelecomLogo(size: 32),
                      const Spacer(),
                      // Admin button
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Row(
                          children: [
                            Text(
                              auth.user?.name.split(' ').first ?? 'admin',
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 13),
                            ),
                            const SizedBox(width: 6),
                            Stack(
                              children: [
                                const Icon(Icons.circle,
                                    color: Colors.red, size: 10),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        icon: const Icon(Icons.logout,
                            color: Colors.white, size: 20),
                        onPressed: () async {
                          await context.read<AuthProvider>().logout();
                          if (!mounted) return;
                          Navigator.of(context).pushAndRemoveUntil(
                            MaterialPageRoute(
                                builder: (_) => const LoginScreen()),
                            (_) => false,
                          );
                        },
                      ),
                    ],
                  ),
                ),
                // Breadcrumb
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 10),
                  color: Colors.white,
                  child: Row(
                    children: [
                      const Icon(Icons.home,
                          color: AppTheme.primary, size: 18),
                      const SizedBox(width: 6),
                      const Text('Home',
                          style: TextStyle(color: Colors.grey, fontSize: 13)),
                      const Icon(Icons.chevron_right,
                          color: Colors.grey, size: 16),
                      Text(_getTitle(),
                          style: const TextStyle(
                              fontSize: 13, fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),
                // Page content
                Expanded(child: _buildBody()),
                // Footer
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 10),
                  color: Colors.white,
                  child: const Text(
                    '© MD Telecom admin 2025',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Sidebar Widgets ───────────────────────────────────────────

class _SidebarItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final Widget? trailing;
  final VoidCallback onTap;

  const _SidebarItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        color: selected ? AppTheme.sidebarActive : Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Icon(icon,
                color: selected ? Colors.white : Colors.white60, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Text(label,
                  style: TextStyle(
                      color: selected ? Colors.white : Colors.white70,
                      fontSize: 13,
                      fontWeight: selected
                          ? FontWeight.w600
                          : FontWeight.normal)),
            ),
            if (trailing != null) trailing!,
          ],
        ),
      ),
    );
  }
}

class _SidebarSubItem extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _SidebarSubItem({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        color: selected ? AppTheme.sidebarActive : Colors.transparent,
        padding: const EdgeInsets.only(left: 48, right: 16, top: 10, bottom: 10),
        child: Text(label,
            style: TextStyle(
                color: selected ? Colors.white : Colors.white60,
                fontSize: 12,
                fontWeight:
                    selected ? FontWeight.w600 : FontWeight.normal)),
      ),
    );
  }
}

// ── Coming Soon placeholder ───────────────────────────────────
class _ComingSoon extends StatelessWidget {
  final String label;
  const _ComingSoon({required this.label});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.construction, size: 64, color: Colors.grey),
          const SizedBox(height: 12),
          Text('$label – Coming Soon',
              style: const TextStyle(color: Colors.grey, fontSize: 16)),
        ],
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  final bool hasChildren;
  _NavItem({required this.icon, required this.label, this.hasChildren = false});
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:ecommerce_mobile/core/theme/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../services/api_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? _stats;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final api = context.read<AuthProvider>().apiService;
    try {
      final res = await api.getDashboard();
      if (mounted) {
        setState(() {
          _stats   = res['data']['stats'] as Map<String, dynamic>;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    final total     = _stats?['total_orders']     ?? 0;
    final completed = _stats?['completed_orders'] ?? 0;
    final pending   = _stats?['pending_orders']   ?? 0;
    final rejected  = _stats?['rejected_orders']  ?? 0;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Row 1: Big stat cards ─────────────────────────────
          Row(
            children: [
              Expanded(
                child: _BigStatCard(
                  value: '$total',
                  label: 'Total Order',
                  icon: Icons.person_outline,
                  color: AppTheme.cardOrange,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _BigStatCard(
                  value: '$completed',
                  label: 'Completed Order',
                  icon: Icons.person_outline,
                  color: AppTheme.cardTeal,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _BigStatCard(
                  value: '$pending',
                  label: 'Pending Order',
                  icon: Icons.person_outline,
                  color: AppTheme.cardGreen,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _BigStatCard(
                  value: '$rejected',
                  label: 'Rejected Order',
                  icon: Icons.person_outline,
                  color: AppTheme.cardRed,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // ── Row 2: Today's stat cards ─────────────────────────
          Row(
            children: [
              Expanded(
                child: _SmallStatCard(
                  value: '$total',
                  label: "Todays Order",
                  icon: Icons.shopping_bag_outlined,
                  color: AppTheme.cardOrange,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SmallStatCard(
                  value: '$completed',
                  label: "Todays Cander Order",
                  icon: Icons.shopping_bag_outlined,
                  color: AppTheme.cardTeal,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SmallStatCard(
                  value: '$pending',
                  label: "Todays Pending Order",
                  icon: Icons.shopping_bag_outlined,
                  color: AppTheme.cardGreen,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SmallStatCard(
                  value: '$rejected',
                  label: "Todays Rejected Order",
                  icon: Icons.shopping_bag_outlined,
                  color: AppTheme.cardRed,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          // ── Recent orders ─────────────────────────────────────
          const Text('Recent Orders',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Consumer<OrderProvider>(
            builder: (_, op, __) {
              if (op.orders.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(
                      child: Text('No orders yet.',
                          style: TextStyle(color: Colors.grey))),
                );
              }
              return Column(
                children: op.orders.take(5).map((o) {
                  Color c;
                  switch (o.status) {
                    case 'completed': c = Colors.green; break;
                    case 'rejected':  c = Colors.red;   break;
                    default:          c = Colors.orange;
                  }
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      dense: true,
                      leading: const Icon(Icons.receipt_long,
                          color: AppTheme.cardOrange),
                      title: Text('Order #${o.id}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 13)),
                      subtitle: Text(
                          '${o.items.length} item(s) · ₱${o.totalAmount.toStringAsFixed(2)}',
                          style: const TextStyle(fontSize: 12)),
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: c,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(o.status.toUpperCase(),
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}

// ── Big stat card (top row) ───────────────────────────────────
class _BigStatCard extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color color;

  const _BigStatCard({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.25),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              const Spacer(),
            ],
          ),
          const SizedBox(height: 12),
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 8),
          Row(
            children: const [
              Text('View All',
                  style: TextStyle(color: Colors.white, fontSize: 11)),
              SizedBox(width: 4),
              Icon(Icons.arrow_forward, color: Colors.white, size: 12),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Small stat card (second row) ─────────────────────────────
class _SmallStatCard extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color color;

  const _SmallStatCard({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 6,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(height: 10),
          Text(value,
              style: TextStyle(
                  color: color,
                  fontSize: 22,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 6),
          Row(
            children: [
              Text('View All',
                  style: TextStyle(color: color, fontSize: 11)),
              const SizedBox(width: 4),
              Icon(Icons.arrow_forward, color: color, size: 11),
            ],
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../main.dart';
import '../providers/auth_provider.dart';
import 'auth/login_screen.dart';
import 'main_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await Future.delayed(const Duration(milliseconds: 1800));
    if (!mounted) return;

    final auth = context.read<AuthProvider>();
    await auth.tryAutoLogin();

    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) =>
          auth.isLoggedIn ? const MainScreen() : const LoginScreen(),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.navyBg,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _MDTelecomLogo(size: 100),
            const SizedBox(height: 32),
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(Colors.white),
              strokeWidth: 2,
            ),
          ],
        ),
      ),
    );
  }
}

// ── Reusable MD Telecom Logo Widget ──────────────────────────
class MDTelecomLogo extends StatelessWidget {
  final double size;
  const MDTelecomLogo({super.key, this.size = 60});

  @override
  Widget build(BuildContext context) => _MDTelecomLogo(size: size);
}

class _MDTelecomLogo extends StatelessWidget {
  final double size;
  const _MDTelecomLogo({required this.size});

  @override
  Widget build(BuildContext context) {
    final fontSize = size * 0.38;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text('MD',
                style: TextStyle(
                  fontSize: fontSize,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.primary,
                  letterSpacing: 1,
                )),
            const SizedBox(width: 4),
            Text('D',
                style: TextStyle(
                  fontSize: fontSize,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  letterSpacing: 1,
                )),
          ],
        ),
        Text('TELECOM',
            style: TextStyle(
              fontSize: fontSize * 0.38,
              fontWeight: FontWeight.w600,
              color: Colors.white,
              letterSpacing: 4,
            )),
      ],
    );
  }
}

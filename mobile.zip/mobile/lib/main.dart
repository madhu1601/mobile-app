import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'providers/auth_provider.dart';
import 'providers/cart_provider.dart';
import 'providers/product_provider.dart';
import 'providers/order_provider.dart';
import 'screens/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const MDTelecomApp());
}

class MDTelecomApp extends StatelessWidget {
  const MDTelecomApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => ProductProvider()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(create: (_) => OrderProvider()),
      ],
      child: MaterialApp(
        title: 'MD Telecom',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        home: const SplashScreen(),
      ),
    );
  }
}

class AppTheme {
  // Brand colours
  static const Color navyBg    = Color(0xFF1E2A3A); // dark sidebar / login bg
  static const Color primary   = Color(0xFFE53935); // MD red
  static const Color sidebarBg = Color(0xFF1A2535);
  static const Color sidebarActive = Color(0xFF243447);

  // Stat card colours
  static const Color cardOrange = Color(0xFFF57C00);
  static const Color cardTeal   = Color(0xFF00897B);
  static const Color cardGreen  = Color(0xFF43A047);
  static const Color cardRed    = Color(0xFFE53935);

  // Product screen
  static const Color addBtn    = Color(0xFF1A237E); // dark navy blue
  static const Color removeBtn = Color(0xFFE53935);
  static const Color priceTag  = Color(0xFF43A047);
  static const Color bottomBar = Color(0xFF1A237E);

  static final ThemeData light = ThemeData(
    useMaterial3: false,
    primaryColor: primary,
    scaffoldBackgroundColor: const Color(0xFFF0F2F5),
    fontFamily: 'Roboto',
    appBarTheme: const AppBarTheme(
      backgroundColor: navyBg,
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        minimumSize: const Size(double.infinity, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        elevation: 0,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(6),
        borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(6),
        borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(6),
        borderSide: const BorderSide(color: primary, width: 1.5),
      ),
    ),
  );
}

import 'package:flutter/material.dart';

class MDTelecomLogo extends StatelessWidget {
  final double size;

  const MDTelecomLogo({super.key, this.size = 60});

  @override
  Widget build(BuildContext context) {
    return Icon(Icons.phone_android, size: size);
  }
}